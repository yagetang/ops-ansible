#ifndef JEMALLOC_INTERNAL_BASE_INLINES_H
#define JEMALLOC_INTERNAL_BASE_INLINES_H

static inline unsigned
base_ind_get(const base_t *base) {
	return base->ind;
}

#endif /* JEMALLOC_INTERNAL_BASE_INLINES_H */
